export interface BaseTableData {
  id: string;
  [key: string]: any;
}
