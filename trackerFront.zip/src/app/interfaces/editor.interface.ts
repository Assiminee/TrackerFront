export interface Editor {
  userId: string;
  firstName: string;
  lastName: string;
}
